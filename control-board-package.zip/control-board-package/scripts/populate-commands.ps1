# populate-commands.ps1
# Populate Control Board Command Center with OpenClaw commands

Write-Host "╔════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║  Control Board - Populate OpenClaw Commands           ║" -ForegroundColor Green
Write-Host "╚════════════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""

# Check if DASHBOARD_URL is set
if (-not $env:DASHBOARD_URL) {
    Write-Host "Enter your dashboard URL:" -ForegroundColor Yellow
    Write-Host "(e.g., https://control-board-xxxxx.vercel.app)" -ForegroundColor Yellow
    $DASHBOARD_URL = Read-Host "URL"
} else {
    $DASHBOARD_URL = $env:DASHBOARD_URL
}

# Check if TOKEN is set
if (-not $env:TOKEN) {
    Write-Host ""
    Write-Host "Get your API token:" -ForegroundColor Yellow
    Write-Host "1. Go to $DASHBOARD_URL/control"
    Write-Host "2. Click 'Copy Token' at the top"
    Write-Host "3. Paste it below"
    Write-Host ""
    $TOKEN = Read-Host "Token"
} else {
    $TOKEN = $env:TOKEN
}

Write-Host ""
Write-Host "Adding OpenClaw commands to Command Center..." -ForegroundColor Green
Write-Host ""

# Headers for all requests
$headers = @{
    "Authorization" = "Bearer $TOKEN"
    "Content-Type" = "application/json"
}

# Function to add command
function Add-Command($name, $description, $category, $group) {
    Write-Host "Adding $name... " -NoNewline
    $body = @{
        name = $name
        description = $description
        category = $category
        command_group = $group
        steps = @()
    } | ConvertTo-Json

    try {
        Invoke-RestMethod -Uri "$DASHBOARD_URL/api/commands" -Method POST -Headers $headers -Body $body -ErrorAction Stop | Out-Null
        Write-Host "✓" -ForegroundColor Green
    } catch {
        Write-Host "✗" -ForegroundColor Red
    }
}

# Add all commands
Add-Command "/setup" "Connect your Control Board dashboard to OpenClaw" "openclaw" "integration"
Add-Command "/idea" "Add a new idea to your Ideas board" "openclaw" "boards"
Add-Command "/business" "Create a new Business board" "openclaw" "boards"
Add-Command "/commands" "Add a command to your Command Center" "openclaw" "boards"
Add-Command "/resource" "Add a resource link to a Business board" "openclaw" "boards"
Add-Command "/vault" "Save something to your Operator Vault" "openclaw" "boards"
Add-Command "/status" "Check your Control Center status" "openclaw" "monitoring"

Write-Host ""
Write-Host "✓ Done!" -ForegroundColor Green
Write-Host ""
Write-Host "View your commands at:"
Write-Host "$DASHBOARD_URL/commands"
