# Control Board Scripts

Helper scripts for setting up and managing your Control Board.

---

## populate-commands

Automatically populate your Command Center with all OpenClaw commands.

### What It Does

Adds these commands to your dashboard:
- `/setup` - Connect dashboard to OpenClaw
- `/idea` - Add to Ideas board
- `/business` - Create Business board
- `/commands` - Add to Command Center
- `/resource` - Add resource link
- `/vault` - Save to Vault
- `/status` - Check Control Center status

---

## Usage

### Mac/Linux

1. Make the script executable:
   ```bash
   chmod +x scripts/populate-commands.sh
   ```

2. Run the script:
   ```bash
   ./scripts/populate-commands.sh
   ```

3. Enter your dashboard URL when prompted
4. Enter your API token when prompted

**Or set variables first:**
```bash
export DASHBOARD_URL="https://your-board.vercel.app"
export TOKEN="your-api-token-here"
./scripts/populate-commands.sh
```

---

### Windows (PowerShell)

1. Open PowerShell in the workspace folder

2. Run the script:
   ```powershell
   .\scripts\populate-commands.ps1
   ```

3. Enter your dashboard URL when prompted
4. Enter your API token when prompted

**Or set variables first:**
```powershell
$env:DASHBOARD_URL = "https://your-board.vercel.app"
$env:TOKEN = "your-api-token-here"
.\scripts\populate-commands.ps1
```

---

## Getting Your API Token

1. Go to your dashboard (e.g., `https://your-board.vercel.app`)
2. Click **Control** in the left sidebar
3. At the top, click **Copy Token**
4. Use this token when running the script

---

## Troubleshooting

### "Permission denied" (Mac/Linux)
Run: `chmod +x scripts/populate-commands.sh`

### "Script execution is disabled" (Windows)
Run PowerShell as Administrator and execute:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### "Unauthorized" / 401 Error
- Check that you copied the full API token
- Token may have expired - get a fresh one from the Control page
- Verify the dashboard URL is correct

### Commands Already Exist
The script will show "✗" for commands that already exist. This is normal if you've run the script before.

---

## Manual Alternative

If you prefer, you can add commands manually via the dashboard:
1. Go to your dashboard → Custom Commands
2. Click "Add Command"
3. Fill in the details for each command

Or follow Step 10 in `DEPLOY-CONTROL-BOARD.md` for manual curl commands.

---

## What Gets Created

Each command is added with:
- **Name:** `/command-name`
- **Description:** What the command does
- **Category:** `openclaw` (for easy filtering)
- **Command Group:** `integration`, `boards`, or `monitoring`

You can view and edit all commands in your dashboard at:
`https://your-board.vercel.app/commands`

---

**Built for OpenClaw 🤖**
