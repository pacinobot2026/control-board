#!/bin/bash

# populate-commands.sh
# Populate Control Board Command Center with OpenClaw commands

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${GREEN}╔════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║  Control Board - Populate OpenClaw Commands           ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════════════╝${NC}"
echo ""

# Check if DASHBOARD_URL is set
if [ -z "$DASHBOARD_URL" ]; then
    echo -e "${YELLOW}Enter your dashboard URL:${NC}"
    echo -e "${YELLOW}(e.g., https://control-board-xxxxx.vercel.app)${NC}"
    read -p "URL: " DASHBOARD_URL
fi

# Check if TOKEN is set
if [ -z "$TOKEN" ]; then
    echo ""
    echo -e "${YELLOW}Get your API token:${NC}"
    echo "1. Go to $DASHBOARD_URL/control"
    echo "2. Click 'Copy Token' at the top"
    echo "3. Paste it below"
    echo ""
    read -p "Token: " TOKEN
fi

echo ""
echo -e "${GREEN}Adding OpenClaw commands to Command Center...${NC}"
echo ""

# Setup command
echo -n "Adding /setup... "
curl -s -X POST "$DASHBOARD_URL/api/commands" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"/setup","description":"Connect your Control Board dashboard to OpenClaw","category":"openclaw","command_group":"integration","steps":[]}' > /dev/null 2>&1
if [ $? -eq 0 ]; then echo -e "${GREEN}✓${NC}"; else echo -e "${RED}✗${NC}"; fi

# Idea command
echo -n "Adding /idea... "
curl -s -X POST "$DASHBOARD_URL/api/commands" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"/idea","description":"Add a new idea to your Ideas board","category":"openclaw","command_group":"boards","steps":[]}' > /dev/null 2>&1
if [ $? -eq 0 ]; then echo -e "${GREEN}✓${NC}"; else echo -e "${RED}✗${NC}"; fi

# Business command
echo -n "Adding /business... "
curl -s -X POST "$DASHBOARD_URL/api/commands" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"/business","description":"Create a new Business board","category":"openclaw","command_group":"boards","steps":[]}' > /dev/null 2>&1
if [ $? -eq 0 ]; then echo -e "${GREEN}✓${NC}"; else echo -e "${RED}✗${NC}"; fi

# Commands command
echo -n "Adding /commands... "
curl -s -X POST "$DASHBOARD_URL/api/commands" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"/commands","description":"Add a command to your Command Center","category":"openclaw","command_group":"boards","steps":[]}' > /dev/null 2>&1
if [ $? -eq 0 ]; then echo -e "${GREEN}✓${NC}"; else echo -e "${RED}✗${NC}"; fi

# Resource command
echo -n "Adding /resource... "
curl -s -X POST "$DASHBOARD_URL/api/commands" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"/resource","description":"Add a resource link to a Business board","category":"openclaw","command_group":"boards","steps":[]}' > /dev/null 2>&1
if [ $? -eq 0 ]; then echo -e "${GREEN}✓${NC}"; else echo -e "${RED}✗${NC}"; fi

# Vault command
echo -n "Adding /vault... "
curl -s -X POST "$DASHBOARD_URL/api/commands" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"/vault","description":"Save something to your Operator Vault","category":"openclaw","command_group":"boards","steps":[]}' > /dev/null 2>&1
if [ $? -eq 0 ]; then echo -e "${GREEN}✓${NC}"; else echo -e "${RED}✗${NC}"; fi

# Status command
echo -n "Adding /status... "
curl -s -X POST "$DASHBOARD_URL/api/commands" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"/status","description":"Check your Control Center status","category":"openclaw","command_group":"monitoring","steps":[]}' > /dev/null 2>&1
if [ $? -eq 0 ]; then echo -e "${GREEN}✓${NC}"; else echo -e "${RED}✗${NC}"; fi

echo ""
echo -e "${GREEN}✓ Done!${NC}"
echo ""
echo "View your commands at:"
echo "$DASHBOARD_URL/commands"
