# Resource Command - Add Resource Link

Add a resource link to a Business board in the dashboard.

User input: `$ARGUMENTS`

Expected format: `<title> <url>`

Example: `/resource Sales Page https://example.com/sales`

---

## Step 1 — Load config

Read `.openclaw/dashboard-config.json` from the workspace.

**If the file doesn't exist or is missing `url` or `token`:**

Say:
```
⚠️ Dashboard not connected yet. Run **/setup** first — it only takes a minute!
```
Stop here.

Extract `url` and `token` from the config.

---

## Step 2 — Check the input

If `$ARGUMENTS` is empty or blank:

Say:
```
🔗 What resource do you want to add?

Format: `/resource <title> <url>`

Examples:
- `/resource Sales Page https://example.com/sales`
- `/resource Product Demo https://youtube.com/watch?v=...`
- `/resource Figma Designs https://figma.com/file/...`

*(The URL is optional — you can just add a title if you don't have a link yet.)*
```
Stop here.

**Parse the input:**

- Look for a URL (starts with `http://` or `https://`)
- If found: everything before it is the **title**, the URL is the **url**
- If not found: use all of `$ARGUMENTS` as the **title**, leave **url** blank

---

## Step 3 — Find available businesses

Make this API call:

```bash
curl -s -X GET "[url]/api/businesses" \
  -H "Authorization: Bearer [token]"
```

Parse the JSON response to get the list of businesses.

**If the response is empty or has no businesses:**

Say:
```
🏢 You don't have any Business boards yet.

Create one first:
`/business <name>`

Then try adding a resource.
```
Stop here.

**If there is exactly one business:**

Use that business automatically. Extract its `id` as `business_id`.

Tell the user:
```
Adding to your **[business name]** board...
```

**If there are multiple businesses:**

List them and ask the user to choose:

Say:
```
Which business should this go to? Reply with the number:

1. [First business name]
2. [Second business name]
3. [Third business name]
...
```

Wait for the user's number response and extract the corresponding `business_id`.

---

## Step 4 — Create the resource

Make this API call:

```bash
curl -s -X POST "[url]/api/businesses" \
  -H "Authorization: Bearer [token]" \
  -H "Content-Type: application/json" \
  -d '{"action": "add_resource", "business_id": "[business_id]", "title": "[title]", "url": "[url]", "type": "link"}'
```

Replace `[url]`, `[token]`, `[business_id]`, `[title]`, and `[url]` with appropriate values.

---

## Step 5 — Handle the response

**If successful (HTTP 200 or 201):**

Say:
```
✅ Resource added!

**"[title]"** is now on your **[business name]** board.

→ View it: [url]/businesses
```

**If you get a 401 error (Unauthorized):**

Say:
```
🔑 Your token has expired.

To fix it:
1. Go to [url]/control
2. Click **Copy Token**
3. Run **/setup** and paste the new token

Then try /resource again!
```

**If any other error:**

Say:
```
❌ Something went wrong: [error message]

If this keeps happening, run **/setup** to check your connection.
```

---

## Notes for OpenClaw

- Uses the config from `.openclaw/dashboard-config.json`
- API endpoint: `POST /api/businesses`
- Action: `add_resource`
- Required fields: `business_id`, `title`, `type`
- Optional fields: `url`, `description`
- Type defaults to "link"
- Requires at least one business to exist
