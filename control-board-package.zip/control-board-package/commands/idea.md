# Idea Command - Add to Ideas Board

Add a new idea to the Ideas board in the dashboard.

User input: `$ARGUMENTS`

---

## Step 1 — Load config

Read `.openclaw/dashboard-config.json` from the workspace.

**If the file doesn't exist or is missing `url` or `token`:**

Say:
```
⚠️ Dashboard not connected yet. Run **/setup** first — it only takes a minute!
```
Stop here.

Extract `url` and `token` from the config.

---

## Step 2 — Check for idea text

If `$ARGUMENTS` is empty or blank:

Say:
```
💡 What's the idea?

Examples:
- `/idea Buy a new microphone for recordings`
- `/idea Create a video series on productivity hacks`
- `/idea Launch a newsletter about AI tools`
```
Stop here.

---

## Step 3 — Create the idea

Make this API call:

```bash
curl -s -X POST "[url]/api/ideas" \
  -H "Authorization: Bearer [token]" \
  -H "Content-Type: application/json" \
  -d '{"title": "$ARGUMENTS", "status": "active", "priority": "medium"}'
```

Replace `[url]` and `[token]` with values from the config.

---

## Step 4 — Handle the response

**If successful (HTTP 200 or 201):**

Say:
```
✅ Idea added!

**"$ARGUMENTS"** is now on your Ideas board.

→ View it: [url]/ideas
```

**If you get a 401 error (Unauthorized):**

Say:
```
🔑 Your token has expired.

To fix it:
1. Go to [url]/control
2. Click **Copy Token**
3. Run **/setup** and paste the new token

Then try /idea again!
```

**If any other error:**

Say:
```
❌ Something went wrong: [error message]

If this keeps happening, run **/setup** to check your connection.
```

---

## Notes for OpenClaw

- Uses the config from `.openclaw/dashboard-config.json`
- API endpoint: `POST /api/ideas`
- Required fields: `title`, `status`, `priority`
- Default priority is "medium", default status is "active"
