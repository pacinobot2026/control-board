# Control Board Commands for OpenClaw

These commands allow OpenClaw to interact with your deployed Control Board dashboard.

---

## 🎯 What These Commands Do

- **`/setup`** - Connect your dashboard (one-time setup)
- **`/idea`** - Add ideas to your Ideas board
- **`/business`** - Create new Business boards
- **`/commands`** - Add custom commands to Command Center
- **`/resource`** - Add resource links to Business boards
- **`/vault`** - Save items to your Operator Vault
- **`/status`** - Check Control Center status

---

## 🔧 How It Works

### Configuration

1. **Dashboard URL** is read from `.env.local` in your workspace:
   ```env
   NEXT_PUBLIC_DASHBOARD_URL=https://your-control-board.vercel.app
   ```

2. **API Token** is stored in `.openclaw/dashboard-config.json`:
   ```json
   {
     "url": "https://your-control-board.vercel.app",
     "token": "eyJhbGci...",
     "lastUpdated": "2026-03-16T19:30:00Z"
   }
   ```

### First Time Setup

1. Deploy your control board to Vercel (see `DEPLOY-CONTROL-BOARD.md`)
2. Add the dashboard URL to your `.env.local` file
3. Run `/setup` command to connect OpenClaw
4. Get your API token from the Control page and paste it
5. Start using the commands!

---

## 📝 Usage Examples

### Setup (first time)
```
/setup
```
OpenClaw will:
- Read your dashboard URL from `.env.local`
- Ask for your API token
- Save the config
- Test the connection

### Add an Idea
```
/idea Create a video series on productivity hacks
```

### Create a Business Board
```
/business Self Mastery Co
```

### Add a Command
```
/commands /morning - Run my morning content review routine
```

### Add a Resource
```
/resource Sales Page https://example.com/sales
```

### Save to Vault
```
/vault API Keys - credentials
```

### Check Status
```
/status
```

---

## 🔑 Security Notes

- **API Token:** Your token is like a password. Keep it secure.
- **Token Expiration:** Tokens may expire. If commands stop working, run `/setup` again.
- **Config File:** Add `.openclaw/dashboard-config.json` to `.gitignore` to keep your token private.
- **Environment File:** Never commit `.env.local` to version control.

---

## 🛠️ Troubleshooting

### "Dashboard not connected" Error
**Fix:** Run `/setup` first to connect your dashboard.

### "Token has expired" Error
**Fix:**
1. Go to your dashboard Control page
2. Click "Copy Token"
3. Run `/setup` and paste the new token

### "Couldn't find dashboard URL" Error
**Fix:** Add this to your `.env.local`:
```env
NEXT_PUBLIC_DASHBOARD_URL=https://your-control-board.vercel.app
```

### API Calls Failing
**Checklist:**
1. Dashboard is deployed and accessible
2. `.env.local` has the correct URL
3. API token is valid (check in dashboard Control page)
4. `.openclaw/dashboard-config.json` exists and has url + token
5. Your dashboard has the required API endpoints

---

## 📚 API Endpoints Reference

All commands use these API endpoints on your deployed dashboard:

| Command | Method | Endpoint | Body |
|---------|--------|----------|------|
| setup | GET | `/api/control` | - |
| idea | POST | `/api/ideas` | `{title, status, priority}` |
| business | POST | `/api/businesses` | `{action, name}` |
| commands | POST | `/api/commands` | `{name, description, category, command_group}` |
| resource | POST | `/api/businesses` | `{action, business_id, title, url, type}` |
| vault | POST | `/api/vault/items` | `{title, category, type, url, notes, tags}` |
| status | GET | `/api/control` | - |

All requests require:
- Header: `Authorization: Bearer [token]`
- Header: `Content-Type: application/json` (for POST)

---

## 🎓 Integration with OpenClaw

These commands are designed to work as:

1. **Custom commands** - OpenClaw can recognize `/idea`, `/vault`, etc. as custom shortcuts
2. **Skills** - Can be wrapped in OpenClaw skills for more advanced workflows
3. **Tools** - Reference in `TOOLS.md` for your specific setup

### Example TOOLS.md Entry

```markdown
### Control Board

Dashboard URL: https://my-control-board.vercel.app

**Quick Commands:**
- `/setup` - Connect dashboard
- `/idea <text>` - Add idea
- `/business <name>` - Create business board
- `/vault <title>` - Save to vault
- `/status` - Check status

**Token refresh:** Go to dashboard → Control → Copy Token → run `/setup`
```

---

## 🚀 Future Enhancements

Potential additions:
- `/project` - Create project on Project Board
- `/task` - Add task to Kanban board
- `/clip` - Add video clip to Video Cue
- `/wish` - Add item to Wish List
- `/article` - Create article draft
- `/team` - Add team member

---

**Built for OpenClaw 🤖**  
Compatible with Control Board deployment from `DEPLOY-CONTROL-BOARD.md`
