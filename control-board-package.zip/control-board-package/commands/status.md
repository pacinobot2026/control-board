# Status Command - Control Center Status

Show the current status of the Control Center — what's connected, API keys, cron jobs, channels, integrations, tasks, and more.

---

## Step 1 — Load config

Read `.openclaw/dashboard-config.json` from the workspace.

**If the file doesn't exist or is missing `url` or `token`:**

Say:
```
⚠️ Dashboard not connected yet. Run **/setup** first — it only takes a minute!
```
Stop here.

Extract `url` and `token` from the config.

---

## Step 2 — Fetch control center data

Make this API call:

```bash
curl -s -X GET "[url]/api/control" \
  -H "Authorization: Bearer [token]"
```

---

## Step 3 — Handle the response

**If you get a 401 error (Unauthorized):**

Say:
```
🔑 Your token has expired.

To fix it:
1. Go to [url]/control
2. Click **Copy Token**
3. Run **/setup** and paste the new token

Then try /status again!
```
Stop here.

**If successful (HTTP 200):**

Parse the JSON response and display a friendly summary like this:

---

Say:
```
📊 **Control Center Status**

**🔑 API Keys** ([count] connected)
[For each key: show name and status — ✅ for connected, ⚠️ for missing/disconnected]

**🤖 AI Models** ([count] available)
[For each model: show name and provider]

**⏰ Cron Jobs** ([count] total — [X active, Y paused])
[For each job: show name and schedule]

**📋 Tasks** ([count] total)
Backlog: [count] | In Progress: [count] | Done: [count]

**📡 Channels** ([count] connected)
[For each channel: show name and status]

**🔌 Integrations** ([count] total)
[For each integration: show name and status]

**⭐ Features** ([count] total)
[List feature names]

→ Manage everything: [url]/control
```

---

**If any section has no data:**

Show: `[Section name]: None set up yet`

**Examples:**
- `📋 Tasks: None yet`
- `⏰ Cron Jobs: None configured`

---

**If any other error:**

Say:
```
❌ Couldn't fetch status: [error message]

If this keeps happening, run **/setup** to check your connection.
```

---

## Notes for OpenClaw

- Uses the config from `.openclaw/dashboard-config.json`
- API endpoint: `GET /api/control`
- Returns comprehensive status of all dashboard features
- No request body needed
- Response includes: api_keys, models, cron_jobs, tasks, channels, integrations, features
- Great for debugging and seeing what's configured
