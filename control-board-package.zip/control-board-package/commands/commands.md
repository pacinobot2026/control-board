# Commands Command - Add to Command Center

Add a new command to the Command Center in the dashboard.

User input: `$ARGUMENTS`

Expected format: `<name> - <description>`

Example: `/commands /morning - Run my morning content review routine`

---

## Step 1 — Load config

Read `.openclaw/dashboard-config.json` from the workspace.

**If the file doesn't exist or is missing `url` or `token`:**

Say:
```
⚠️ Dashboard not connected yet. Run **/setup** first — it only takes a minute!
```
Stop here.

Extract `url` and `token` from the config.

---

## Step 2 — Check and parse the input

If `$ARGUMENTS` is empty or blank:

Say:
```
⚙️ What command do you want to add?

Format: `/commands <name> - <description>`

Examples:
- `/commands /morning - Run my morning content review routine`
- `/commands /deploy - Deploy the latest changes to production`
- `/commands /backup - Backup all important files`
```
Stop here.

**Parse the input:**

Split `$ARGUMENTS` on the first ` - ` (space-dash-space):
- Everything **before** ` - ` is the **name**
- Everything **after** ` - ` is the **description**

If there's no ` - ` separator:
- Use the entire `$ARGUMENTS` as the **name**
- Use `"No description provided"` as the **description**

---

## Step 3 — Create the command

Make this API call:

```bash
curl -s -X POST "[url]/api/commands" \
  -H "Authorization: Bearer [token]" \
  -H "Content-Type: application/json" \
  -d '{"name": "[name]", "description": "[description]", "category": "custom", "command_group": "user", "steps": []}'
```

Replace `[url]`, `[token]`, `[name]`, and `[description]` with the appropriate values.

---

## Step 4 — Handle the response

**If successful (HTTP 200 or 201):**

Say:
```
✅ Command added!

**"[name]"** is now in your Command Center.

→ View it: [url]/commands
```

**If you get a 401 error (Unauthorized):**

Say:
```
🔑 Your token has expired.

To fix it:
1. Go to [url]/control
2. Click **Copy Token**
3. Run **/setup** and paste the new token

Then try /commands again!
```

**If you get a 400 error about unique constraint:**

Say:
```
⚠️ A command named **"[name]"** already exists.

Try a slightly different name.
```

**If any other error:**

Say:
```
❌ Something went wrong: [error message]

If this keeps happening, run **/setup** to check your connection.
```

---

## Notes for OpenClaw

- Uses the config from `.openclaw/dashboard-config.json`
- API endpoint: `POST /api/commands`
- Required fields: `name`, `description`, `category`, `command_group`
- Optional fields: `steps` (array), `tags`, `icon`
- Category defaults to "custom"
- Command group defaults to "user"
