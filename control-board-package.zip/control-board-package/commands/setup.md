# Setup Command - Connect Dashboard

Help the user connect their control board dashboard so all the other commands (`/idea`, `/business`, `/commands`, `/resource`, `/vault`, `/status`) can work.

---

## Step 1 — Check for existing config

Read the file `.openclaw/dashboard-config.json` in the workspace.

- If it exists and has a valid `token`, tell the user:
  ```
  ✅ You're already set up! Your dashboard is connected.
  
  Dashboard URL: [url from .env.local or config]
  
  If you need to update your token, just run /setup again.
  ```
  Then stop.

- If it doesn't exist or is missing the token, proceed to Step 2.

---

## Step 2 — Read Dashboard URL from .env.local

Try to read `.env.local` from the workspace root.

Look for a line that contains:
- `NEXT_PUBLIC_DASHBOARD_URL=` or
- `DASHBOARD_URL=` or
- `NEXT_PUBLIC_SUPABASE_URL=` (fallback if dashboard URL not specified)

Extract the URL value and save it as `dashboardUrl`.

**If .env.local doesn't exist or doesn't have a dashboard URL:**

Say:
```
⚠️ I couldn't find your dashboard URL in `.env.local`.

Please add one of these lines to your `.env.local` file:
NEXT_PUBLIC_DASHBOARD_URL=https://your-control-board.vercel.app

Or tell me your dashboard URL now and I'll save it.
```

Wait for the user's response. If they provide a URL, save it to the config and proceed.

---

## Step 3 — Ask for the Bearer Token

Say:
```
🔑 **Let's connect your dashboard!**

Your dashboard URL: [dashboardUrl]

Now I just need your API token. Here's how to get it:

1. Go to your dashboard: [dashboardUrl]
2. Click **Control** in the left sidebar
3. Look for **API Access** at the top
4. Click **Copy Token**
5. Paste the token here 👇

*(Your token is like a password for the API. It may expire after a while, so if commands stop working, just run /setup again to paste a new one.)*
```

Wait for the user's response. Save it as `token`.

---

## Step 4 — Save the config

Create the directory `.openclaw` if it doesn't exist.

Write this JSON to `.openclaw/dashboard-config.json`:
```json
{
  "url": "[dashboardUrl]",
  "token": "[token]",
  "lastUpdated": "[current ISO timestamp]"
}
```

---

## Step 5 — Test the connection

Make a test API call to verify the token works:

```bash
curl -s -X GET "[dashboardUrl]/api/control" \
  -H "Authorization: Bearer [token]"
```

**If it returns 401 or auth error:**
Say:
```
❌ The token didn't work. Please double-check:
1. You copied the full token (no spaces)
2. The token is from the Control page of your dashboard
3. Your dashboard is running at [dashboardUrl]

Try running /setup again with a fresh token.
```

**If successful:**
Say:
```
🎉 All set! Your dashboard is now connected.

**Dashboard:** [dashboardUrl]

**Available commands:**
- `/idea <text>` — Add a new idea to your Ideas board
- `/business <name>` — Create a new Business board
- `/commands <name> - <description>` — Add a command to Command Center
- `/resource <title> <url>` — Add a resource link to a business
- `/vault <title>` — Save something to your Vault
- `/status` — Check Control Center status

Try one now! 🚀
```

---

## Notes for OpenClaw

- This command reads the dashboard URL from `.env.local` (user's environment)
- The API token is stored in `.openclaw/dashboard-config.json` (workspace config)
- Token should be kept secure and not committed to git
- Add `.openclaw/dashboard-config.json` to `.gitignore` if using version control
