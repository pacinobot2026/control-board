# Vault Command - Save to Vault

Save something to the Operator Vault in the dashboard.

User input: `$ARGUMENTS`

Expected format: `<title>` or `<title> <url>` or `<title> - <category>`

Examples:
- `/vault My favourite productivity book`
- `/vault Morning Routine Video https://youtube.com/...`
- `/vault Cold Email Template - templates`

---

## Step 1 — Load config

Read `.openclaw/dashboard-config.json` from the workspace.

**If the file doesn't exist or is missing `url` or `token`:**

Say:
```
⚠️ Dashboard not connected yet. Run **/setup** first — it only takes a minute!
```
Stop here.

Extract `url` and `token` from the config.

---

## Step 2 — Check for input

If `$ARGUMENTS` is empty or blank:

Say:
```
🔒 What do you want to save to the Vault?

Formats:
- `/vault <title>`
- `/vault <title> <url>`
- `/vault <title> - <category>`

Examples:
- `/vault Morning Routine Checklist`
- `/vault Sales Script https://docs.google.com/...`
- `/vault Swipe File - templates`
- `/vault API Keys - credentials`
```
Stop here.

---

## Step 3 — Parse the input

From `$ARGUMENTS`, extract:

1. **Check for URL:** If there's a URL (`http://` or `https://`):
   - Everything before the URL is the **title**
   - The URL is the **url**
   - **type** = `"link"`

2. **Check for category:** If there's ` - <word>` at the end (and it's not a URL):
   - Everything before ` - ` is the **title**
   - Everything after ` - ` is the **category**
   - **type** = `"note"` (unless URL was found)

3. **Default values:**
   - If no category specified: **category** = `"general"`
   - If no URL and no category: use full `$ARGUMENTS` as **title**
   - **type** = `"note"` if no URL, `"link"` if URL present

---

## Step 4 — Save to Vault

Make this API call:

```bash
curl -s -X POST "[url]/api/vault/items" \
  -H "Authorization: Bearer [token]" \
  -H "Content-Type: application/json" \
  -d '{"title": "[title]", "category": "[category]", "type": "[type]", "url": "[url or null]", "notes": "", "tags": []}'
```

Replace `[url]`, `[token]`, `[title]`, `[category]`, `[type]`, and optional `[url]` with values from parsing.

If there's no URL, use `null` for the url field.

---

## Step 5 — Handle the response

**If successful (HTTP 200 or 201):**

Say:
```
✅ Saved to Vault!

**"[title]"** is now in your Vault under **[category]**.

→ View it: [url]/vault
```

**If you get a 401 error (Unauthorized):**

Say:
```
🔑 Your token has expired.

To fix it:
1. Go to [url]/control
2. Click **Copy Token**
3. Run **/setup** and paste the new token

Then try /vault again!
```

**If any other error:**

Say:
```
❌ Something went wrong: [error message]

If this keeps happening, run **/setup** to check your connection.
```

---

## Notes for OpenClaw

- Uses the config from `.openclaw/dashboard-config.json`
- API endpoint: `POST /api/vault/items`
- Required fields: `title`, `category`, `type`
- Optional fields: `url`, `notes`, `tags`
- Types: `"note"` (text), `"link"` (URL), `"credential"` (password/key)
- Categories: `"general"`, `"credentials"`, `"templates"`, or custom
- Tags are optional array of strings
