# Business Command - Create Business Board

Create a new Business board in the dashboard.

User input: `$ARGUMENTS`

---

## Step 1 — Load config

Read `.openclaw/dashboard-config.json` from the workspace.

**If the file doesn't exist or is missing `url` or `token`:**

Say:
```
⚠️ Dashboard not connected yet. Run **/setup** first — it only takes a minute!
```
Stop here.

Extract `url` and `token` from the config.

---

## Step 2 — Check for business name

If `$ARGUMENTS` is empty or blank:

Say:
```
🏢 What should this business board be called?

Examples:
- `/business Self Mastery Co`
- `/business West Valley Properties`
- `/business Creative Studio`
```
Stop here.

---

## Step 3 — Create the business

Make this API call:

```bash
curl -s -X POST "[url]/api/businesses" \
  -H "Authorization: Bearer [token]" \
  -H "Content-Type: application/json" \
  -d '{"action": "add_business", "name": "$ARGUMENTS"}'
```

Replace `[url]` and `[token]` with values from the config.

---

## Step 4 — Handle the response

**If successful (HTTP 200 or 201):**

Say:
```
✅ Business board created!

**"$ARGUMENTS"** is now on your Businesses page.

→ View it: [url]/businesses

💡 Tip: Add resources to this board with `/resource <title> <url>`
```

**If you get a 401 error (Unauthorized):**

Say:
```
🔑 Your token has expired.

To fix it:
1. Go to [url]/control
2. Click **Copy Token**
3. Run **/setup** and paste the new token

Then try /business again!
```

**If you get a 400 error about duplicates:**

Say:
```
⚠️ A business named **"$ARGUMENTS"** already exists.

Try a slightly different name, or check your Businesses page.
```

**If any other error:**

Say:
```
❌ Something went wrong: [error message]

If this keeps happening, run **/setup** to check your connection.
```

---

## Notes for OpenClaw

- Uses the config from `.openclaw/dashboard-config.json`
- API endpoint: `POST /api/businesses`
- Action: `add_business`
- Required field: `name`
