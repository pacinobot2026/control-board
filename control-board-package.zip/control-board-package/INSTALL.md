# Installation Guide

**Quick guide to install and use the Control Board package.**

---

## 📥 Installation (30 seconds)

### Step 1: Copy to Workspace

Copy the entire `control-board-package` folder into your OpenClaw workspace:

```bash
# Your workspace structure:
workspace/
├── control-board-package/    ← This folder
├── AGENTS.md
├── SOUL.md
├── USER.md
└── ... (other workspace files)
```

**That's it for installation!** OpenClaw will automatically detect the skills.

---

## 🚀 First-Time Setup

### 1. Deploy Your Dashboard (15-20 min)

Open and follow:
```
control-board-package/DEPLOY-CONTROL-BOARD.md
```

This will:
- Fork the GitHub repository
- Set up Supabase database
- Deploy to Vercel
- Run database migrations
- Create your first user

**Result:** Dashboard live at `https://your-board.vercel.app`

---

### 2. Configure Environment (1 min)

Create or edit `.env.local` in your workspace root:

```env
NEXT_PUBLIC_DASHBOARD_URL=https://your-board.vercel.app
```

**Why:** OpenClaw needs to know your dashboard URL.

---

### 3. Connect OpenClaw (1 min)

Just say:
```
"Connect my dashboard"
```

OpenClaw will:
1. Read URL from `.env.local`
2. Ask for your API token
3. Save config to `.openclaw/dashboard-config.json`
4. Test the connection

**Get API token:**
1. Go to `https://your-board.vercel.app/control`
2. Click "Copy Token"
3. Paste in chat

---

### 4. Test It (10 seconds)

Try a command:
```
"Add an idea: Test the Control Board integration"
```

If it works, you're all set! 🎉

---

## 🔄 Updating the Package

If you receive an updated version:

1. **Backup your config:**
   ```bash
   cp .openclaw/dashboard-config.json dashboard-config-backup.json
   ```

2. **Replace the package:**
   - Delete old `control-board-package` folder
   - Copy new `control-board-package` folder

3. **Restore your config:**
   ```bash
   cp dashboard-config-backup.json .openclaw/dashboard-config.json
   ```

Your dashboard connection will remain intact.

---

## 🗑️ Uninstallation

To remove the Control Board integration:

1. **Delete the package:**
   ```bash
   rm -rf control-board-package
   ```

2. **Remove config (optional):**
   ```bash
   rm .openclaw/dashboard-config.json
   ```

3. **Remove dashboard URL from `.env.local`** (optional)

Your deployed dashboard will remain live (if you want to delete it, do so in Vercel/Supabase).

---

## 📁 What Gets Created

### By This Package
```
workspace/
└── control-board-package/
    ├── README.md
    ├── DEPLOY-CONTROL-BOARD.md
    ├── CONTROL-BOARD-SETUP.md
    ├── skills/
    ├── commands/
    └── scripts/
```

### By OpenClaw (Auto-Created)
```
workspace/
├── .env.local                      ← You create this
└── .openclaw/
    └── dashboard-config.json       ← Auto-created on setup
```

---

## ✅ Post-Installation Checklist

After installation, verify:

- [ ] `control-board-package` folder in workspace
- [ ] Dashboard deployed to Vercel
- [ ] `.env.local` has `NEXT_PUBLIC_DASHBOARD_URL`
- [ ] OpenClaw connected ("Connect my dashboard")
- [ ] `.openclaw/dashboard-config.json` exists
- [ ] Test command works ("Add idea: test")

---

## 🛡️ Security Checklist

Make sure to:

- [ ] Add `.openclaw/` to `.gitignore`
- [ ] Never commit `dashboard-config.json`
- [ ] Keep API token private
- [ ] Use strong dashboard password
- [ ] Don't share `.env.local` with secrets

---

## 📚 Next Steps

After installation:

1. **Read the overview:**
   ```
   control-board-package/CONTROL-BOARD-SETUP.md
   ```

2. **Try the examples:**
   ```
   control-board-package/skills/control-board/EXAMPLES.md
   ```

3. **Explore the dashboard:**
   - Visit `https://your-board.vercel.app`
   - Navigate all 10+ boards
   - Try adding items manually

4. **Use natural commands:**
   - "Add idea: [text]"
   - "Create business: [name]"
   - "Save to vault: [title]"

---

## 🆘 Troubleshooting

### OpenClaw Doesn't Detect Skills

**Check:**
- `control-board-package` is in workspace root
- Folder name is exactly `control-board-package`
- `skills/control-board/SKILL.md` exists

**Fix:**
- Restart OpenClaw
- Check workspace path is correct

### Commands Not Working

**Check:**
- Dashboard is deployed and accessible
- `.env.local` has dashboard URL
- `.openclaw/dashboard-config.json` exists
- API token is valid (not expired)

**Fix:**
- Run "Connect my dashboard" again
- Get fresh token from Control page

### Files Missing After Update

**Prevention:**
- Always backup `.openclaw/dashboard-config.json`
- Don't store custom files in `control-board-package`

---

## 💡 Tips

- **Keep package separate:** Don't modify files in `control-board-package` - they may be overwritten on updates
- **Use .env.local:** Store your dashboard URL there, not in the package
- **Backup config:** Save `.openclaw/dashboard-config.json` before updates
- **Check for updates:** New versions may have bug fixes and features

---

**Installation complete! Ready to use.** 🚀

See `README.md` for full documentation.
