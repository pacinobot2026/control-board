# Control Board Skill - Usage Examples

Real-world examples of using the Control Board skill with OpenClaw.

---

## Example 1: First Time Setup

**Scenario:** User has deployed their Control Board and wants to connect OpenClaw.

**User:** "Connect my control board"

**OpenClaw:**
```
👋 Let's connect your dashboard!

I found your dashboard URL in .env.local:
https://my-control-board.vercel.app

Now I need your API token. Here's how to get it:

1. Go to https://my-control-board.vercel.app/control
2. Click **Copy Token** at the top
3. Paste the token here 👇
```

**User:** [pastes token] `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`

**OpenClaw:**
```
🎉 All set! Your dashboard is now connected.

**Dashboard:** https://my-control-board.vercel.app

**What you can do:**
- Add ideas: "add an idea: Create video series"
- Create businesses: "create business board: Self Mastery Co"
- Save to vault: "save to vault: API Keys"
- Check status: "what's my dashboard status?"

Try one now!
```

---

## Example 2: Adding Ideas

**User:** "I have an idea: Launch a weekly newsletter about AI tools for creators"

**OpenClaw:**
```
✅ Idea added!

**"Launch a weekly newsletter about AI tools for creators"** is now on your Ideas board.

→ View it: https://my-control-board.vercel.app/ideas
```

---

## Example 3: Creating Multiple Businesses

**User:** "Create these business boards: Self Mastery Co, West Valley Properties, Creative Studio"

**OpenClaw:**
```
Creating 3 business boards...

✅ Business board created!
**"Self Mastery Co"** is now on your Businesses page.

✅ Business board created!
**"West Valley Properties"** is now on your Businesses page.

✅ Business board created!
**"Creative Studio"** is now on your Businesses page.

→ View all: https://my-control-board.vercel.app/businesses

💡 Tip: Add resources to these boards with:
"add resource: Sales Page https://example.com"
```

---

## Example 4: Adding Commands

**User:** "Add these commands to my command center:
- /morning - Run my morning content review routine
- /backup - Backup all important files to cloud storage
- /deploy - Deploy the latest changes to production"

**OpenClaw:**
```
Adding 3 commands...

✅ Command added!
**"/morning"** is now in your Command Center.

✅ Command added!
**"/backup"** is now in your Command Center.

✅ Command added!
**"/deploy"** is now in your Command Center.

→ View all: https://my-control-board.vercel.app/commands
```

---

## Example 5: Saving to Vault

**User:** "Save these to my vault:
- Stripe API Key - credentials
- Email Templates - templates
- Brand Guidelines https://figma.com/brand-guide"

**OpenClaw:**
```
Saving 3 items to Vault...

✅ Saved to Vault!
**"Stripe API Key"** is now in your Vault under **credentials**.

✅ Saved to Vault!
**"Email Templates"** is now in your Vault under **templates**.

✅ Saved to Vault!
**"Brand Guidelines"** is now in your Vault under **general** with link.

→ View all: https://my-control-board.vercel.app/vault
```

---

## Example 6: Adding Resources to Business

**User:** "Add this resource to Self Mastery Co: Sales Page https://selfmastery.com/sales"

**OpenClaw:**
```
Adding to your **Self Mastery Co** board...

✅ Resource added!

**"Sales Page"** is now on your **Self Mastery Co** board.

→ View it: https://my-control-board.vercel.app/businesses
```

---

## Example 7: Token Expired

**User:** "Add idea: Create morning routine video"

**OpenClaw:**
```
🔑 Your token has expired.

To fix it:
1. Go to https://my-control-board.vercel.app/control
2. Click **Copy Token**
3. Paste the new token here 👇
```

**User:** [pastes new token]

**OpenClaw:**
```
✅ Token updated! Now adding your idea...

✅ Idea added!

**"Create morning routine video"** is now on your Ideas board.

→ View it: https://my-control-board.vercel.app/ideas
```

---

## Example 8: Checking Dashboard Status

**User:** "What's my dashboard status?"

**OpenClaw:**
```
📊 **Control Center Status**

**🔑 API Keys** (3 connected)
✅ Stripe API
✅ OpenAI API
⚠️ PostBridge API (missing)

**🤖 AI Models** (2 available)
• GPT-4 (OpenAI)
• Claude 3.5 Sonnet (Anthropic)

**⏰ Cron Jobs** (2 total — 2 active, 0 paused)
• Daily backup (runs at 2:00 AM)
• Weekly report (runs Mondays at 9:00 AM)

**📋 Tasks** (12 total)
Backlog: 5 | In Progress: 4 | Done: 3

**📡 Channels** (2 connected)
• Slack
• Discord

**🔌 Integrations** (3 total)
• Stripe (active)
• Letterman (active)
• PostBridge (inactive)

→ Manage everything: https://my-control-board.vercel.app/control
```

---

## Example 9: Multiple Resources at Once

**User:** "I need to add these resources to West Valley Properties:
- Property Listings https://zillow.com/listings
- Mortgage Calculator https://calculator.com
- Market Analysis Report https://drive.google.com/report"

**OpenClaw:**
```
Adding 3 resources to **West Valley Properties**...

✅ Resource added!
**"Property Listings"** is now on your **West Valley Properties** board.

✅ Resource added!
**"Mortgage Calculator"** is now on your **West Valley Properties** board.

✅ Resource added!
**"Market Analysis Report"** is now on your **West Valley Properties** board.

→ View all: https://my-control-board.vercel.app/businesses
```

---

## Example 10: Complex Vault Items

**User:** "Save these important things to my vault:
- AWS Access Keys - credentials
- Content Calendar Template https://notion.so/calendar - templates
- Backup codes for 2FA - credentials
- Video Editing Workflow"

**OpenClaw:**
```
Saving 4 items to Vault...

✅ Saved to Vault!
**"AWS Access Keys"** is now in your Vault under **credentials**.

✅ Saved to Vault!
**"Content Calendar Template"** is now in your Vault under **templates** with link.

✅ Saved to Vault!
**"Backup codes for 2FA"** is now in your Vault under **credentials**.

✅ Saved to Vault!
**"Video Editing Workflow"** is now in your Vault under **general**.

→ View all: https://my-control-board.vercel.app/vault
```

---

## Example 11: Mixed Commands in Conversation

**User:** "Hey, can you help me organize some things? I want to add an idea about launching a podcast, create a business board for my consulting work, and save my Notion template to the vault."

**OpenClaw:**
```
Sure! Let me help you organize those three things.

1️⃣ **Adding your podcast idea...**

✅ Idea added!
**"Launching a podcast"** is now on your Ideas board.

2️⃣ **Creating business board...**

✅ Business board created!
**"Consulting Work"** is now on your Businesses page.

3️⃣ **Saving to vault...**

✅ Saved to Vault!
**"Notion template"** is now in your Vault under **general**.

All done! Here's what I added:
→ Ideas: https://my-control-board.vercel.app/ideas
→ Businesses: https://my-control-board.vercel.app/businesses
→ Vault: https://my-control-board.vercel.app/vault
```

---

## Tips for Best Results

### Be Natural
You don't need exact commands - just speak naturally:
- ✅ "I have an idea about creating a course"
- ✅ "add idea: creating a course"
- ✅ "save this idea: creating a course"

### Batch Operations
Process multiple items at once:
- "Add these 3 ideas: [idea1], [idea2], [idea3]"
- OpenClaw will handle them one by one

### Context Matters
OpenClaw remembers your dashboard URL and token:
- No need to specify it each time
- Just say what you want to add

### Token Management
When token expires, just paste a new one:
- OpenClaw will guide you through it
- No manual config editing needed

---

## Common Patterns

### Adding Ideas
```
"add an idea: [text]"
"I have an idea: [text]"
"save this idea: [text]"
```

### Creating Businesses
```
"create business board: [name]"
"new business: [name]"
"add business: [name]"
```

### Adding Commands
```
"add command: [name] - [description]"
"save command: [name] - [description]"
```

### Adding Resources
```
"add resource: [title] [url]"
"save link: [title] [url]"
"add this to [business]: [title] [url]"
```

### Saving to Vault
```
"save to vault: [title]"
"add to vault: [title] - [category]"
"vault: [title] [url]"
```

### Checking Status
```
"what's my dashboard status?"
"check control center"
"show me the dashboard stats"
```

---

**These examples show the skill in action! Try them yourself. 🚀**
