# Control Board Skill

**Interact with your deployed Control Board dashboard from OpenClaw.**

---

## What This Does

Connect OpenClaw to your Control Board dashboard to:
- ✅ Add ideas to Ideas board
- ✅ Create Business boards
- ✅ Add commands to Command Center
- ✅ Save resources and links
- ✅ Store items in Operator Vault
- ✅ Check Control Center status

---

## Quick Start

### 1. Deploy Control Board

Follow the deployment guide: `DEPLOY-CONTROL-BOARD.md` (in workspace root)

### 2. Add Dashboard URL to .env.local

```env
NEXT_PUBLIC_DASHBOARD_URL=https://your-control-board.vercel.app
```

### 3. Connect from OpenClaw

Just say: **"Connect my dashboard"** or **"Setup control board"**

OpenClaw will:
- Read your dashboard URL from `.env.local`
- Ask for your API token (from dashboard Control page)
- Save the config
- Test the connection

### 4. Start Using Commands

Natural language works:
- "Add an idea: Create video series on productivity"
- "Create business board: Self Mastery Co"
- "Save to vault: API Keys"
- "What's my dashboard status?"

---

## Configuration

**Dashboard URL:** Stored in `.env.local`
```env
NEXT_PUBLIC_DASHBOARD_URL=https://your-board.vercel.app
```

**API Token:** Stored in `.openclaw/dashboard-config.json`
```json
{
  "url": "https://your-board.vercel.app",
  "token": "eyJhbGci...",
  "lastUpdated": "2026-03-16T19:30:00Z"
}
```

**Security:**
- Add `.openclaw/dashboard-config.json` to `.gitignore`
- Never commit your API token
- Token may expire - OpenClaw will guide you to refresh it

---

## Commands Available

| User Says | What Happens | Board |
|-----------|--------------|-------|
| "Add idea: [text]" | Creates new idea | Ideas |
| "Create business: [name]" | Creates business board | Businesses |
| "Add command: [name] - [desc]" | Adds command | Command Center |
| "Add resource: [title] [url]" | Adds resource link | Businesses |
| "Save to vault: [title]" | Saves vault item | Vault |
| "Check status" | Shows dashboard status | Control |

---

## Troubleshooting

### "Dashboard not connected"
→ Run setup by saying: "Connect my dashboard"

### "Token expired"
→ OpenClaw will ask for a fresh token:
1. Go to your dashboard → Control page
2. Click "Copy Token"
3. Paste it in chat

### "Dashboard URL not found"
→ Add to `.env.local`:
```env
NEXT_PUBLIC_DASHBOARD_URL=https://your-board.vercel.app
```

---

## Files Structure

```
workspace/
├── .env.local                          # Dashboard URL
├── .openclaw/
│   └── dashboard-config.json           # API token (gitignored)
├── commands/                            # Command implementations
│   ├── setup.md
│   ├── idea.md
│   ├── business.md
│   ├── commands.md
│   ├── resource.md
│   ├── vault.md
│   └── status.md
├── skills/
│   └── control-board/
│       ├── SKILL.md                    # This skill
│       └── README.md                   # You are here
└── DEPLOY-CONTROL-BOARD.md            # Deployment guide
```

---

## API Endpoints Used

All endpoints are on your deployed dashboard:

- `GET /api/control` - Status and test connection
- `POST /api/ideas` - Add idea
- `POST /api/businesses` - Create business or add resource
- `POST /api/commands` - Add command
- `POST /api/vault/items` - Save to vault

All requests require:
```
Authorization: Bearer [token]
Content-Type: application/json
```

---

## Natural Language Examples

OpenClaw understands these patterns:

**Ideas:**
- "add an idea: [text]"
- "save this idea: [text]"
- "I have an idea: [text]"

**Business:**
- "create business board: [name]"
- "new business: [name]"

**Commands:**
- "add command: [name] - [description]"
- "save this command: [name] - [description]"

**Resources:**
- "add resource: [title] [url]"
- "save this link: [title] [url]"

**Vault:**
- "save to vault: [title]"
- "add to vault: [title] - [category]"

**Status:**
- "what's my dashboard status?"
- "show control center"

---

## Related Documentation

- **Deployment:** `DEPLOY-CONTROL-BOARD.md` - How to deploy dashboard
- **Commands:** `commands/README.md` - Command reference
- **Source:** https://github.com/pacinobot2026/control-board

---

## Version

**Version:** 1.0  
**Last Updated:** 2026-03-16  
**Compatible With:** Control Board v1.0+  
**OpenClaw:** Compatible with all versions

---

**Built for OpenClaw 🤖**
