# Control Board Skill

Interact with a deployed Control Board dashboard - add ideas, create business boards, manage vault items, and more.

---

## When to Use This Skill

Use this skill when the user wants to:
- Add an idea to their Ideas board
- Create a new Business board
- Add a command to their Command Center
- Save a resource link to a Business board
- Store something in their Operator Vault
- Check their Control Center status
- Set up their dashboard connection for the first time

**Prerequisites:**
- User has deployed a Control Board (see `DEPLOY-CONTROL-BOARD.md` in workspace)
- Dashboard URL is in `.env.local` as `NEXT_PUBLIC_DASHBOARD_URL` or similar

---

## How This Skill Works

### Configuration

**Dashboard URL:**
Read from `.env.local` in the workspace root. Look for:
- `NEXT_PUBLIC_DASHBOARD_URL=`
- `DASHBOARD_URL=`
- Or as fallback: `NEXT_PUBLIC_SUPABASE_URL=`

**API Token:**
Stored in `.openclaw/dashboard-config.json`:
```json
{
  "url": "https://control-board.vercel.app",
  "token": "eyJhbGci...",
  "lastUpdated": "2026-03-16T19:30:00Z"
}
```

### First Time Setup

If the user has never connected their dashboard, they need to run setup first.

---

## Command Reference

All command details are in the `commands/` folder (workspace root). Reference them as needed:

- `commands/setup.md` - Connect dashboard
- `commands/idea.md` - Add to Ideas board
- `commands/business.md` - Create Business board
- `commands/commands.md` - Add to Command Center
- `commands/resource.md` - Add resource link
- `commands/vault.md` - Save to Vault
- `commands/status.md` - Check status

---

## Skill Workflow

### Step 1: Determine User Intent

What does the user want to do?

- "add an idea" → Idea command
- "create a business board" → Business command
- "add a command" → Commands command
- "add a resource" → Resource command
- "save to vault" → Vault command
- "check status" → Status command
- "setup dashboard" / "connect dashboard" → Setup command

### Step 2: Check Configuration

Before running any command (except setup), verify config exists:

```javascript
// Read .openclaw/dashboard-config.json
```

**If config is missing or invalid:**
- Tell user: "⚠️ Dashboard not connected yet. Let me help you set it up first."
- Proceed with Setup workflow

**If config exists:**
- Extract `url` and `token`
- Proceed with the requested command

### Step 3: Execute Command

Read the appropriate command file from `commands/` and follow its instructions.

For example, if user wants to add an idea:
1. Read `commands/idea.md`
2. Follow the steps outlined there
3. Make the API call using `exec` tool
4. Handle the response

### Step 4: Handle Errors

**401 Unauthorized:**
Token has expired. Guide user to refresh:
```
🔑 Your token has expired.

To fix it:
1. Go to [url]/control
2. Click **Copy Token**
3. I'll update the config with your new token.

Paste the token here 👇
```

Wait for token, update `.openclaw/dashboard-config.json`, retry the command.

**Other errors:**
Show the error message and suggest running setup to verify connection.

---

## Setup Workflow (First Time)

When user needs to connect their dashboard:

### Step 1: Read Dashboard URL from .env.local

```bash
# Read .env.local and extract dashboard URL
```

Look for lines containing:
- `NEXT_PUBLIC_DASHBOARD_URL=`
- `DASHBOARD_URL=`
- `NEXT_PUBLIC_SUPABASE_URL=` (fallback)

Extract the URL value.

**If .env.local doesn't exist or has no dashboard URL:**

Ask user:
```
⚠️ I couldn't find your dashboard URL.

Do you have a Control Board deployed?
- If yes, what's the URL? (e.g., https://control-board.vercel.app)
- If no, I can help you deploy one first.
```

If they provide URL, save it to memory and proceed.

### Step 2: Ask for API Token

Say:
```
🔑 Let's connect your dashboard!

Your dashboard URL: [url]

I need your API token. Here's how to get it:

1. Go to [url]/control
2. Click **Copy Token** at the top
3. Paste the token here 👇

(Your token may expire after a while. If commands stop working, I'll ask for a fresh one.)
```

Wait for user to paste the token.

### Step 3: Save Configuration

Create `.openclaw/` directory if needed.

Write to `.openclaw/dashboard-config.json`:
```json
{
  "url": "[the url]",
  "token": "[the token they pasted]",
  "lastUpdated": "[current ISO timestamp]"
}
```

### Step 4: Test Connection

Make a test API call:

```bash
curl -s -X GET "[url]/api/control" \
  -H "Authorization: Bearer [token]"
```

**If successful:**
```
🎉 All set! Your dashboard is now connected.

**Dashboard:** [url]

**What you can do:**
- Add ideas: "add an idea: Create video series"
- Create businesses: "create business board: Self Mastery Co"
- Save to vault: "save to vault: API Keys"
- Check status: "what's my dashboard status?"

Try one now!
```

**If it fails (401 or other error):**
```
❌ Couldn't connect. Please check:
1. You copied the full token (no spaces)
2. The token is from [url]/control
3. Your dashboard is running

Let's try again - paste a fresh token:
```

Wait for new token and retry.

---

## API Call Examples

### Add an Idea

```bash
curl -s -X POST "[url]/api/ideas" \
  -H "Authorization: Bearer [token]" \
  -H "Content-Type: application/json" \
  -d '{"title": "User idea text", "status": "active", "priority": "medium"}'
```

### Create Business Board

```bash
curl -s -X POST "[url]/api/businesses" \
  -H "Authorization: Bearer [token]" \
  -H "Content-Type: application/json" \
  -d '{"action": "add_business", "name": "Business Name"}'
```

### Add Command

```bash
curl -s -X POST "[url]/api/commands" \
  -H "Authorization: Bearer [token]" \
  -H "Content-Type: application/json" \
  -d '{"name": "/command", "description": "Description", "category": "custom", "command_group": "user", "steps": []}'
```

### Save to Vault

```bash
curl -s -X POST "[url]/api/vault/items" \
  -H "Authorization: Bearer [token]" \
  -H "Content-Type: application/json" \
  -d '{"title": "Item title", "category": "general", "type": "note", "url": null, "notes": "", "tags": []}'
```

### Get Status

```bash
curl -s -X GET "[url]/api/control" \
  -H "Authorization: Bearer [token]"
```

---

## Natural Language Patterns

Listen for these user patterns:

**Ideas:**
- "add an idea: [text]"
- "save this idea: [text]"
- "add to ideas board: [text]"

**Business:**
- "create business board: [name]"
- "new business: [name]"
- "add business: [name]"

**Commands:**
- "add command: [name] - [description]"
- "save command: [name] - [description]"

**Resources:**
- "add resource: [title] [url]"
- "save link: [title] [url]"

**Vault:**
- "save to vault: [title]"
- "add to vault: [title]"
- "vault: [title]"

**Status:**
- "what's my dashboard status?"
- "check control center"
- "show dashboard status"

**Setup:**
- "connect my dashboard"
- "setup control board"
- "connect control board"

---

## Error Handling

### Common Issues

**"Dashboard not connected"**
→ Run setup workflow

**"Token expired" (401)**
→ Ask for fresh token, update config, retry

**"Table does not exist" errors**
→ User needs to run database migrations (see DEPLOY-CONTROL-BOARD.md Step 7)

**"Dashboard URL not found"**
→ Ask user for URL or help them deploy dashboard

**API endpoint returns 404**
→ Dashboard might not have that API endpoint implemented

**Network errors**
→ Check if dashboard URL is accessible

---

## Tips for Natural Usage

- **Be conversational:** User doesn't need to know about config files
- **Helpful errors:** Guide them to fix issues, don't just report errors
- **Proactive:** If setup is needed, offer to do it immediately
- **Confirmations:** After successful actions, show what was added and link to view it
- **Token refresh:** Make it painless when token expires

---

## Example Conversations

### First Time User

**User:** "Add an idea: Create a video series on productivity"

**You:** 
```
⚠️ Dashboard not connected yet. Let me help you set it up first!

Do you have a Control Board deployed? If so, what's the URL?
(e.g., https://control-board.vercel.app)
```

**User:** "https://my-board.vercel.app"

**You:**
```
Great! Now I need your API token.

1. Go to https://my-board.vercel.app/control
2. Click **Copy Token**
3. Paste it here 👇
```

**User:** [pastes token]

**You:**
```
🎉 Connected! Now adding your idea...

✅ Idea added!

**"Create a video series on productivity"** is now on your Ideas board.

→ View it: https://my-board.vercel.app/ideas
```

### Returning User

**User:** "Save to vault: API Keys"

**You:**
```
✅ Saved to Vault!

**"API Keys"** is now in your Vault under **general**.

→ View it: https://my-board.vercel.app/vault
```

### Token Expired

**User:** "Add business: West Valley Properties"

**You:**
```
🔑 Your token has expired.

To fix it:
1. Go to https://my-board.vercel.app/control
2. Click **Copy Token**
3. Paste the new token here 👇
```

**User:** [pastes new token]

**You:**
```
✅ Token updated! Now creating your business board...

✅ Business board created!

**"West Valley Properties"** is now on your Businesses page.

→ View it: https://my-board.vercel.app/businesses
```

---

## Security Notes

- **Never log or expose the API token** in responses
- **Config file should be .gitignored**
- **Token is sensitive** - treat it like a password
- **Refresh tokens when needed** - don't make users manually edit config

---

## Related Files

- **Deployment guide:** `DEPLOY-CONTROL-BOARD.md` (workspace root)
- **Command details:** `commands/` folder (workspace root)
- **Commands README:** `commands/README.md`

---

## Skill Metadata

**Name:** control-board  
**Version:** 1.0  
**Author:** OpenClaw  
**Compatible with:** Control Board dashboard (pacinobot2026/control-board)  
**Dependencies:** None (uses built-in exec tool)  
**Config:** `.openclaw/dashboard-config.json`, `.env.local`

---

**Ready to use! 🚀**
