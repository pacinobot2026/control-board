# Control Board - Complete Setup Guide

**Everything you need to deploy and use the Control Board with OpenClaw.**

---

## 🎯 What You're Getting

A complete multi-board operational dashboard system that integrates with OpenClaw:

### 10+ Boards Available
- **Command Center** - Business intelligence dashboard
- **Custom Commands** - OpenClaw command reference
- **Business Board** - Track projects and revenue streams
- **Operator Vault** - Secure credentials storage
- **Project Board** - Kanban-style task management
- **Article Board** - Content publishing workflow
- **Idea Board** - Idea capture and organization
- **Video Cue** - Video clip management
- **Wish List** - Shopping and resource tracking
- **Resource Library** - Link organization

### OpenClaw Integration
Talk to your dashboard naturally:
- "Add an idea: Create a podcast series"
- "Create business board: Self Mastery Co"
- "Save to vault: API Keys"
- "What's my dashboard status?"

---

## 📚 Documentation Map

This workspace contains everything you need:

### 1. Deployment Guide
**File:** `DEPLOY-CONTROL-BOARD.md`

Step-by-step instructions to:
- Fork the GitHub repository
- Set up Supabase database
- Deploy to Vercel
- Run database migrations
- Set up authentication
- Test your deployment

**Start here if:** You haven't deployed the Control Board yet.

---

### 2. Skill Documentation
**Location:** `skills/control-board/`

Three files:
- **SKILL.md** - Complete implementation guide for OpenClaw
- **README.md** - Quick reference and troubleshooting
- **EXAMPLES.md** - 11 real-world usage examples

**Start here if:** Your Control Board is deployed and you want to connect OpenClaw.

---

### 3. Command Reference
**Location:** `commands/`

Individual command implementation files:
- `setup.md` - Connect dashboard to OpenClaw
- `idea.md` - Add to Ideas board
- `business.md` - Create Business boards
- `commands.md` - Add to Command Center
- `resource.md` - Add resource links
- `vault.md` - Save to Operator Vault
- `status.md` - Check Control Center status
- `README.md` - Commands overview

**Start here if:** You want to understand how each command works.

---

## 🚀 Quick Start (4 Steps)

### Step 1: Deploy Your Control Board

Follow `DEPLOY-CONTROL-BOARD.md`:
1. Fork the GitHub repo
2. Set up Supabase
3. Deploy to Vercel
4. Run 12 database migrations
5. Create your first user

**Time:** ~15-20 minutes  
**Result:** Your dashboard is live at `https://your-board.vercel.app`

---

### Step 2: Add Dashboard URL to .env.local

In your workspace, create or edit `.env.local`:

```env
NEXT_PUBLIC_DASHBOARD_URL=https://your-board.vercel.app
```

**Why:** OpenClaw needs to know where your dashboard is.

---

### Step 3: Populate OpenClaw Commands (Optional)

Add OpenClaw commands to your dashboard's Command Center:

**Easy way (recommended):**
```bash
# Mac/Linux
./scripts/populate-commands.sh

# Windows
.\scripts\populate-commands.ps1
```

This adds all 7 OpenClaw commands to your Command Center for easy reference.

See `scripts/README.md` for details.

---

### Step 4: Connect OpenClaw

Just say to OpenClaw: **"Connect my dashboard"**

OpenClaw will:
1. Read the URL from `.env.local`
2. Ask you for your API token
3. Save the configuration
4. Test the connection

**Get your API token:**
1. Go to `https://your-board.vercel.app/control`
2. Click "Copy Token" at the top
3. Paste it in chat

**That's it!** You're ready to use natural commands.

---

## 💬 Using Natural Commands

Once connected, just talk naturally to OpenClaw:

### Add Ideas
```
"Add an idea: Launch a weekly AI newsletter"
"I have an idea: Create morning routine video"
```

### Create Businesses
```
"Create business board: Self Mastery Co"
"New business: West Valley Properties"
```

### Add Commands
```
"Add command: /morning - Run morning content review"
"Save this command: /backup - Backup all files"
```

### Add Resources
```
"Add resource: Sales Page https://example.com/sales"
"Save this link to Self Mastery Co: Figma Designs https://figma.com/..."
```

### Save to Vault
```
"Save to vault: Stripe API Key - credentials"
"Add to vault: Email Templates - templates"
```

### Check Status
```
"What's my dashboard status?"
"Show me control center"
```

---

## 🔧 Configuration Files

### .env.local (Workspace Root)
```env
# Your deployed dashboard URL
NEXT_PUBLIC_DASHBOARD_URL=https://your-board.vercel.app

# Supabase credentials (if needed locally)
NEXT_PUBLIC_SUPABASE_URL=https://xxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGci...
```

**Purpose:** Environment configuration  
**Commit to git:** Yes (but remove sensitive keys)

---

### .openclaw/dashboard-config.json (Auto-created)
```json
{
  "url": "https://your-board.vercel.app",
  "token": "eyJhbGci...",
  "lastUpdated": "2026-03-16T19:30:00Z"
}
```

**Purpose:** API authentication  
**Commit to git:** NO - Add to `.gitignore`  
**Created by:** OpenClaw when you run setup

---

## 🛡️ Security Best Practices

### ✅ Do This
- Add `.openclaw/dashboard-config.json` to `.gitignore`
- Keep API tokens private (never share them)
- Refresh token when it expires (OpenClaw will guide you)
- Use strong passwords for dashboard login

### ❌ Don't Do This
- Commit `.openclaw/dashboard-config.json` to version control
- Share your API token in screenshots or messages
- Use the same password everywhere
- Leave `.env.local` with sensitive keys in public repos

---

## 🔄 Token Management

### Tokens Can Expire

After a while, API commands may fail with "401 Unauthorized".

**When this happens:**

OpenClaw will say:
```
🔑 Your token has expired.

To fix it:
1. Go to https://your-board.vercel.app/control
2. Click **Copy Token**
3. Paste the new token here 👇
```

**What to do:**
1. Go to the Control page
2. Copy the new token
3. Paste it in chat
4. OpenClaw updates the config automatically
5. Your original command retries

**No manual editing needed!**

---

## 📊 What Each Board Does

### Command Center
Business intelligence dashboard with:
- Sales data tracking
- Ad campaign metrics
- System status monitoring
- KPI overview

### Custom Commands
Store and organize all your custom commands:
- OpenClaw shortcuts
- System commands
- Workflow automations
- Quick reference library

### Business Board
Track multiple business ventures:
- Projects and initiatives
- Revenue streams
- Resources and links
- Business metrics

### Operator Vault
Secure storage for:
- API keys and credentials
- Sensitive documents
- Templates and swipe files
- Important URLs

### Project Board
Kanban-style task management:
- Backlog, In Progress, Done columns
- Drag-and-drop tasks
- Project tracking
- Deadline management

### Article Board
Content publishing workflow:
- Draft articles
- Review and edit
- Publish to Letterman (optional)
- Content calendar

### Idea Board
Capture and organize ideas:
- Quick idea capture
- Priority levels
- Status tracking (active/archived)
- Tag organization

### Video Cue
Video clip management:
- Store video URLs
- Thumbnail previews
- Social publishing (PostBridge integration)
- Clip organization

### Wish List
Shopping and resource tracking:
- Items to buy
- Price tracking
- Purchase status
- Links to products

### Resource Library
Organize useful links:
- Categorized bookmarks
- Quick reference
- Resource sharing
- Link descriptions

---

## 🎓 Learning Path

### Beginner
1. ✅ Deploy Control Board (`DEPLOY-CONTROL-BOARD.md`)
2. ✅ Connect OpenClaw ("connect my dashboard")
3. ✅ Try basic commands (add idea, create business)
4. ✅ Explore the dashboard web interface

### Intermediate
1. ✅ Add resources to business boards
2. ✅ Organize vault with categories
3. ✅ Use all command types
4. ✅ Check status regularly

### Advanced
1. ✅ Integrate Letterman for article publishing
2. ✅ Integrate PostBridge for social publishing
3. ✅ Set up custom cron jobs in Control Center
4. ✅ Batch operations via OpenClaw
5. ✅ Create custom workflows

---

## 🆘 Troubleshooting

### "Dashboard not connected"
→ Run: "Connect my dashboard"

### "Token expired"
→ Get fresh token from Control page, paste in chat

### "Couldn't find dashboard URL"
→ Add to `.env.local`:
```env
NEXT_PUBLIC_DASHBOARD_URL=https://your-board.vercel.app
```

### Database errors
→ Check migrations ran successfully (Step 7 in deployment guide)

### 404 errors on API calls
→ Verify dashboard is deployed and accessible

### Can't log into dashboard
→ Check Supabase Authentication, create new user if needed

---

## 📁 Complete File Structure

```
workspace/
├── .env.local                          # Dashboard URL + env vars
├── .gitignore                          # Add .openclaw/ to this
├── .openclaw/
│   └── dashboard-config.json           # API token (auto-created)
│
├── CONTROL-BOARD-SETUP.md             # This file (overview)
├── DEPLOY-CONTROL-BOARD.md            # Deployment guide
│
├── scripts/
│   ├── README.md                       # Scripts documentation
│   ├── populate-commands.sh            # Mac/Linux helper script
│   └── populate-commands.ps1           # Windows helper script
│
├── skills/
│   └── control-board/
│       ├── SKILL.md                   # Main skill implementation
│       ├── README.md                  # Quick reference
│       └── EXAMPLES.md                # Usage examples
│
└── commands/
    ├── README.md                       # Commands overview
    ├── setup.md                        # Connect dashboard
    ├── idea.md                         # Add to Ideas board
    ├── business.md                     # Create Business boards
    ├── commands.md                     # Add to Command Center
    ├── resource.md                     # Add resource links
    ├── vault.md                        # Save to Vault
    └── status.md                       # Check status
```

---

## 🔗 External Links

- **Source Repository:** https://github.com/pacinobot2026/control-board
- **Vercel Docs:** https://vercel.com/docs
- **Supabase Docs:** https://supabase.com/docs
- **Next.js Docs:** https://nextjs.org/docs

---

## ✅ Pre-Flight Checklist

Before using the Control Board skill:

- [ ] Control Board deployed to Vercel
- [ ] Database migrations completed (all 12)
- [ ] User account created in Supabase
- [ ] Dashboard URL added to `.env.local`
- [ ] OpenClaw commands populated in dashboard (optional)
- [ ] OpenClaw connected (ran "connect my dashboard")
- [ ] API token saved in `.openclaw/dashboard-config.json`
- [ ] Test command works (try "add idea: test")

---

## 🎉 You're Ready!

You now have:
- ✅ Complete deployment guide
- ✅ OpenClaw skill for natural commands
- ✅ Command reference documentation
- ✅ Usage examples
- ✅ Troubleshooting help

**Next:** Deploy your dashboard and start organizing your operations!

---

**Built for OpenClaw 🤖**  
*Making operational dashboards accessible through natural conversation*
