# Control Board - Deployment Guide

A complete step-by-step guide to deploy the Nicely Control Board to Vercel with integrated Supabase backend.

## 🎯 What You're Building

A comprehensive multi-board operational dashboard with:
- **Command Center** - Business intelligence dashboard (sales, ads, systems)
- **Custom Commands** - Complete OpenClaw command reference
- **Business Board** - Track all business projects and revenue streams
- **Operator Vault** - Secure credentials and sensitive info
- **Project Board** - Active projects and tasks (Kanban style)
- **Article Board** - Content review and publishing (Letterman integration)
- **Idea Board** - Capture and organize ideas
- **Video Cue** - Video clips review and social publishing
- **Wish List** - Shopping and resource tracking
- **Resource Library** - Save and organize useful links

All with localStorage caching, password-protected access, and real-time API integrations.

---

## ✅ Prerequisites

Before you start, you need:

- **GitHub account** - https://github.com/signup
- **Vercel account** - https://vercel.com/signup

**That's it!** Supabase will be created automatically via Vercel integration.

---

## 🚀 Deployment Steps

Follow these steps **one at a time**. Complete each step before moving to the next.

---

### ✅ Step 1: Fork the GitHub Repository

**What to do:**

1. Open this link in a new tab: https://github.com/pacinobot2026/control-board
2. Click the **Fork** button (top-right corner)
3. Select your GitHub account as the destination
4. Wait for the fork to complete (should take 5-10 seconds)

**Confirm:**
- [ ] I have successfully forked the repository
- [ ] My forked repo is at: `https://github.com/YOUR_USERNAME/control-board`

**Note down your GitHub username** - you'll need it in the next steps.

---

### ✅ Step 2: Install Supabase Integration (Before Importing Repo)

We'll set up Supabase first, then download the environment variables before importing your repository.

**What to do:**

1. Open Vercel Integrations Marketplace: https://vercel.com/integrations
2. In the search bar, type: **"Supabase"**
3. Click on the **Supabase** integration card
4. Click **"Add Integration"** button
5. You may be asked to select a Vercel account/scope - choose your account
6. Click **"Continue"** or **"Add Integration"**
7. You'll be redirected to Supabase setup page
8. On the Supabase setup page:
   - Choose **"Create new project"** (NOT "Connect existing")
   - Select your **Vercel account/team** from dropdown
   - **Project name:** `control-board` (or any name you like)
   - **Database password:** Choose a strong password
     - **IMPORTANT: Write this down! You'll need it later.**
   - **Region:** Choose closest to you (e.g., `East US (North Virginia)`)
   - **Pricing plan:** Should default to **"Free"**
9. Click **"Create project"** button
10. Wait 30-60 seconds for Supabase to provision your database
11. You should see a success message

**Confirm:**
- [ ] Supabase project created successfully
- [ ] I've saved my database password
- [ ] Project name is: `control-board`

---

### ✅ Step 3: Copy Supabase Environment Variables

Now we'll copy the .env.local file that Supabase generated for us.

**What to do:**

1. After Supabase finishes creating the project, look for a **"Copy snippet"** button on the right side of the page
2. Click the **"Copy snippet"** button
3. Open **Notepad** (Windows) or **TextEdit** (Mac) or any text editor
4. **Paste** the copied content (Ctrl+V or Cmd+V)
5. **Save this file** for now - you'll see something like:

```
NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGci...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGci...
```

6. Keep this notepad window open - we'll use these values in Step 5

**If you can't find the "Copy snippet" button:**
1. Go to your Supabase dashboard: https://supabase.com/dashboard
2. Select your `control-board` project
3. Click **Settings** (gear icon) in the sidebar
4. Click **API** in the left menu
5. Look for **"Copy snippet"** button on the right side
6. If still not there, you'll manually copy the keys shown on that page

**Confirm:**
- [ ] I have copied the .env.local snippet
- [ ] I have pasted it in Notepad/text editor
- [ ] I can see variables like SUPABASE_URL, SUPABASE_ANON_KEY, etc.
- [ ] Notepad is still open with the variables

---

### ✅ Step 4: Connect Vercel to GitHub and Import Repository

Now let's connect Vercel to your GitHub account and import the repository.

**What to do:**

1. Open: https://vercel.com/new
2. If prompted, sign in to your Vercel account
3. You'll see **"Import Git Repository"** or **"Let's build something new"**
4. Look for a section showing **GitHub**
5. If you don't see your repository listed, click:
   - **"Add GitHub Account"** or
   - **"Adjust GitHub App Permissions"** or
   - **"Install"** button next to GitHub
6. You'll be redirected to GitHub authorization page
7. GitHub will ask: **"Where do you want to install Vercel?"**
   - Select your account: **YOUR_USERNAME**
8. Choose repository access:
   - **Recommended:** Select **"Only select repositories"**
     - Click the dropdown and check: `control-board`
   - Or select **"All repositories"**
9. Scroll down and click **"Install"** or **"Install & Authorize"**
10. You'll be redirected back to Vercel
11. Now find your repository: `YOUR_USERNAME/control-board`
12. Click **"Import"** next to it
13. You'll be taken to the **"Configure Project"** screen

**Confirm:**
- [ ] Vercel is connected to my GitHub account
- [ ] I can see the "Configure Project" screen
- [ ] Repository shows: `YOUR_USERNAME/control-board`
- [ ] Framework Preset shows: **Next.js**

**⚠️ STOP HERE - Don't click Deploy yet!**

---

### ✅ Step 5: Add All Environment Variables

Now we'll paste the Supabase variables from your notepad.

**What to do:**

1. On the Vercel "Configure Project" screen
2. Scroll down to the **"Environment Variables"** section
3. Click to expand it if it's collapsed

**Paste All Supabase Variables at Once (Super Easy!)**

4. Open your **Notepad** with the Supabase variables
5. **Select ALL** the content (Ctrl+A) and **Copy** (Ctrl+C)
6. In Vercel, click into the **Environment Variables input field** (the large text area or input box)
7. **Paste** everything (Ctrl+V)
8. **Magic!** ✨ Vercel will automatically parse all the variables and create separate entries for each one
9. Verify that variables like these appear:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `POSTGRES_URL`
10. Make sure **all three environments are checked** for each: Production, Preview, Development

**Optional Variables** (only add if you have these services):

#### LETTERMAN_API_KEY (Optional)
- **Key:** `LETTERMAN_API_KEY`
- **Value:** Your Letterman API key from your Letterman account
- **Environments:** All three
- **Used for:** Article Board publishing features
- Click **"Add"**

#### POSTBRIDGE_API_KEY (Optional)
- **Key:** `POSTBRIDGE_API_KEY`
- **Value:** Your Post Bridge API key from https://postbridge.io
- **Environments:** All three
- **Used for:** Video Cue social publishing
- Click **"Add"**

**Confirm:**
- [ ] All Supabase variables from notepad are added to Vercel
- [ ] All variables show "Production, Preview, Development" checked
- [ ] (Optional) I have added any optional API keys I have

---

### ✅ Step 6: Deploy to Vercel

**What to do:**

1. Scroll to the bottom of the "Configure Project" page
2. Click the big **"Deploy"** button
3. Wait for the build to complete (usually 2-3 minutes)
4. Watch the deployment logs - you'll see:
   - Installing dependencies...
   - Building...
   - Deploying...
5. When complete, you'll see a **"Congratulations!"** screen with confetti 🎉

**Confirm:**
- [ ] Deployment completed successfully
- [ ] I can see the deployment URL (looks like `control-board-xxxxx.vercel.app`)

**Copy and save your deployment URL!**

---

### ✅ Step 7: Run Database Migrations

Now we need to create the database tables. There are **12 migration files** to run in order.

**What to do:**

1. Go to your Supabase dashboard: https://supabase.com/dashboard
2. Select your `control-board` project
3. In the left sidebar, click **SQL Editor**
4. Click **"New Query"** button

**Now run each migration file in order:**

For each of the 12 migrations below, you'll:
- Copy the migration URL
- Open it in a new tab
- Copy all the SQL code
- Paste into Supabase SQL Editor
- Click **"Run"** button
- Wait for "Success. No rows returned"

#### Migration 1: Create clips table
```
https://raw.githubusercontent.com/YOUR_USERNAME/control-board/main/migrations/001_create_clips_table.sql
```
- [ ] Migration 1 completed

#### Migration 2: Create content tables
```
https://raw.githubusercontent.com/YOUR_USERNAME/control-board/main/migrations/002_create_content_tables.sql
```
- [ ] Migration 2 completed

#### Migration 3: Create settings table
```
https://raw.githubusercontent.com/YOUR_USERNAME/control-board/main/migrations/003_create_settings_table.sql
```
- [ ] Migration 3 completed

#### Migration 4: Add Postbridge post_id
```
https://raw.githubusercontent.com/YOUR_USERNAME/control-board/main/migrations/004_add_postbridge_post_id.sql
```
- [ ] Migration 4 completed

#### Migration 5: Add user_id to clips and vault
```
https://raw.githubusercontent.com/YOUR_USERNAME/control-board/main/migrations/005_add_user_id_to_clips_and_vault.sql
```
- [ ] Migration 5 completed

#### Migration 6: Create business tables
```
https://raw.githubusercontent.com/YOUR_USERNAME/control-board/main/migrations/006_create_business_tables.sql
```
- [ ] Migration 6 completed

#### Migration 7: Add user_id to articles
```
https://raw.githubusercontent.com/YOUR_USERNAME/control-board/main/migrations/007_add_user_id_to_articles.sql
```
- [ ] Migration 7 completed

#### Migration 8: Create team board
```
https://raw.githubusercontent.com/YOUR_USERNAME/control-board/main/migrations/008_create_team_board.sql
```
- [ ] Migration 8 completed

#### Migration 9: Create command center tables
```
https://raw.githubusercontent.com/YOUR_USERNAME/control-board/main/migrations/009_create_command_center_tables.sql
```
- [ ] Migration 9 completed

#### Migration 10: Create team members
```
https://raw.githubusercontent.com/YOUR_USERNAME/control-board/main/migrations/010_create_team_members.sql
```
- [ ] Migration 10 completed

#### Migration 11: Create kanban tasks
```
https://raw.githubusercontent.com/YOUR_USERNAME/control-board/main/migrations/011_create_kanban_tasks.sql
```
- [ ] Migration 11 completed

#### Migration 12: Add user_id to commands
```
https://raw.githubusercontent.com/YOUR_USERNAME/control-board/main/migrations/012_add_user_id_to_commands.sql
```
- [ ] Migration 12 completed

**Confirm:**
- [ ] All 12 migrations completed successfully
- [ ] Each migration showed "Success" message

**💡 Tip:** Replace `YOUR_USERNAME` in the URLs above with your actual GitHub username.

---

### ✅ Step 8: Set Up Authentication

Create your first user account.

**What to do:**

1. Still in Supabase dashboard
2. Click **Authentication** in the left sidebar
3. Click **Users** tab
4. Click **"Add user"** button
5. Choose **"Create new user"**
6. Fill in:
   - **Email:** Your email address
   - **Password:** Choose a strong password
   - **Auto Confirm User:** ✅ Check this box
7. Click **"Create user"**

**Confirm:**
- [ ] User created successfully
- [ ] I've saved my login email and password
- [ ] Auto confirm is checked

---

### ✅ Step 9: Test Your Deployment

**What to do:**

1. Open your deployment URL in a new tab (from Step 6)
   - Should look like: `https://control-board-xxxxx.vercel.app`
2. You should see a **login page**
3. Enter the **email and password** you created in Step 8
4. Click **"Sign In"** or press Enter
5. You should be redirected to the dashboard
6. Try navigating between different boards:
   - Command Center
   - Custom Commands
   - Business Board
   - Operator Vault
   - Project Board
   - Article Board
   - Idea Board
   - Video Cue
   - Wish List
   - Resource Library

**Confirm:**
- [ ] The dashboard loads successfully
- [ ] I can log in with my credentials
- [ ] I can see all board options
- [ ] Navigation between boards works

---

### ✅ Step 10: Populate Command Center with OpenClaw Commands (Optional)

Now let's add the OpenClaw commands to your Command Center so they're documented in your dashboard.

**What to do:**

1. Get your API token from the dashboard:
   - Click **Control** in the left sidebar
   - At the top, click **Copy Token**
   - Save this token temporarily (you'll use it below)

---

### Option A: Use Helper Script (Easiest)

We've provided helper scripts to make this super easy!

**Mac/Linux:**
```bash
chmod +x scripts/populate-commands.sh
./scripts/populate-commands.sh
```

**Windows (PowerShell):**
```powershell
.\scripts\populate-commands.ps1
```

The script will:
- Ask for your dashboard URL
- Ask for your API token
- Add all 7 commands automatically
- Show you a success message

See `scripts/README.md` for more details.

---

### Option B: Manual Setup

If you prefer to run commands manually:

2. Open a terminal or command prompt

3. Set your dashboard URL and token as variables:

**Windows (PowerShell):**
```powershell
$DASHBOARD_URL = "https://control-board-xxxxx.vercel.app"
$TOKEN = "paste-your-token-here"
```

**Mac/Linux (Bash):**
```bash
export DASHBOARD_URL="https://control-board-xxxxx.vercel.app"
export TOKEN="paste-your-token-here"
```

4. Run these commands to add all OpenClaw commands:

**Windows (PowerShell):**
```powershell
# Setup command
Invoke-RestMethod -Uri "$DASHBOARD_URL/api/commands" -Method POST -Headers @{"Authorization"="Bearer $TOKEN"; "Content-Type"="application/json"} -Body '{"name":"/setup","description":"Connect your Control Board dashboard to OpenClaw","category":"openclaw","command_group":"integration","steps":[]}'

# Idea command
Invoke-RestMethod -Uri "$DASHBOARD_URL/api/commands" -Method POST -Headers @{"Authorization"="Bearer $TOKEN"; "Content-Type"="application/json"} -Body '{"name":"/idea","description":"Add a new idea to your Ideas board","category":"openclaw","command_group":"boards","steps":[]}'

# Business command
Invoke-RestMethod -Uri "$DASHBOARD_URL/api/commands" -Method POST -Headers @{"Authorization"="Bearer $TOKEN"; "Content-Type"="application/json"} -Body '{"name":"/business","description":"Create a new Business board","category":"openclaw","command_group":"boards","steps":[]}'

# Commands command
Invoke-RestMethod -Uri "$DASHBOARD_URL/api/commands" -Method POST -Headers @{"Authorization"="Bearer $TOKEN"; "Content-Type"="application/json"} -Body '{"name":"/commands","description":"Add a command to your Command Center","category":"openclaw","command_group":"boards","steps":[]}'

# Resource command
Invoke-RestMethod -Uri "$DASHBOARD_URL/api/commands" -Method POST -Headers @{"Authorization"="Bearer $TOKEN"; "Content-Type"="application/json"} -Body '{"name":"/resource","description":"Add a resource link to a Business board","category":"openclaw","command_group":"boards","steps":[]}'

# Vault command
Invoke-RestMethod -Uri "$DASHBOARD_URL/api/commands" -Method POST -Headers @{"Authorization"="Bearer $TOKEN"; "Content-Type"="application/json"} -Body '{"name":"/vault","description":"Save something to your Operator Vault","category":"openclaw","command_group":"boards","steps":[]}'

# Status command
Invoke-RestMethod -Uri "$DASHBOARD_URL/api/commands" -Method POST -Headers @{"Authorization"="Bearer $TOKEN"; "Content-Type"="application/json"} -Body '{"name":"/status","description":"Check your Control Center status","category":"openclaw","command_group":"monitoring","steps":[]}'
```

**Mac/Linux (Bash):**
```bash
# Setup command
curl -X POST "$DASHBOARD_URL/api/commands" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"/setup","description":"Connect your Control Board dashboard to OpenClaw","category":"openclaw","command_group":"integration","steps":[]}'

# Idea command
curl -X POST "$DASHBOARD_URL/api/commands" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"/idea","description":"Add a new idea to your Ideas board","category":"openclaw","command_group":"boards","steps":[]}'

# Business command
curl -X POST "$DASHBOARD_URL/api/commands" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"/business","description":"Create a new Business board","category":"openclaw","command_group":"boards","steps":[]}'

# Commands command
curl -X POST "$DASHBOARD_URL/api/commands" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"/commands","description":"Add a command to your Command Center","category":"openclaw","command_group":"boards","steps":[]}'

# Resource command
curl -X POST "$DASHBOARD_URL/api/commands" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"/resource","description":"Add a resource link to a Business board","category":"openclaw","command_group":"boards","steps":[]}'

# Vault command
curl -X POST "$DASHBOARD_URL/api/commands" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"/vault","description":"Save something to your Operator Vault","category":"openclaw","command_group":"boards","steps":[]}'

# Status command
curl -X POST "$DASHBOARD_URL/api/commands" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"/status","description":"Check your Control Center status","category":"openclaw","command_group":"monitoring","steps":[]}'
```

5. Go to your dashboard → **Custom Commands** page
6. You should see all 7 OpenClaw commands listed!

**Confirm:**
- [ ] All 7 commands appear in Custom Commands page
- [ ] Commands are categorized under "openclaw"

**💡 Note:** This step is optional but recommended. It documents all available OpenClaw commands in your dashboard for easy reference.

---

## 🎉 Deployment Complete!

Your Control Board is now live! 

### What You Can Do Now:

1. **Explore all boards** - Try adding projects, ideas, vault items
2. **Create team members** - Add other users via Supabase Authentication
3. **Add a custom domain** (optional):
   - Go to Vercel → Project Settings → Domains
   - Add your custom domain (like `nicelycontrol.com`)
   - Follow DNS setup instructions
4. **Connect integrations:**
   - Add Letterman API key for article publishing
   - Add Postbridge API key for video social publishing

---

## 🔧 Troubleshooting

### Login Shows "Invalid Credentials"
**Fix:** 
- Verify you're using the email/password from Step 8
- Check that "Auto Confirm User" was enabled
- Try creating a new user in Supabase Authentication

### Page Shows "Database Connection Error"
**Fix:**
1. Make sure all 12 migrations ran successfully
2. Check Supabase project is "Active" (not paused)
3. In Vercel → Settings → Environment Variables → verify all Supabase vars are set
4. Try redeploying: Vercel → Deployments → Three dots → Redeploy

### Build Failed During Deployment
**Fix:**
1. Go to Vercel → Deployments → click the failed deployment
2. Check the build logs for specific errors
3. Most common: missing environment variables
4. Go to Settings → Environment Variables → verify all required vars are set
5. Redeploy after fixing

### "Table does not exist" Errors
**Fix:**
- You need to run all 12 migration files in Supabase SQL Editor
- Go back to Step 7 and run each migration again in order
- Make sure you see "Success" for each one
- Verify tables exist: Supabase → Table Editor → check for tables

### 500 Internal Server Error
**Fix:**
1. Vercel → Deployments → click your deployment → Functions tab
2. Look for error logs
3. Usually means:
   - Missing environment variable
   - Database connection issue
   - Migration not run
4. Check all environment variables are set
5. Verify migrations completed

### Some Boards Show Empty or Error
**Fix:**
- Check that specific migration for that board ran successfully
- Example: Business Board needs migration #6
- Example: Command Center needs migration #9
- Re-run the specific migration in Supabase SQL Editor

---

## 📚 Environment Variables Reference

### Auto-Created by Supabase Integration
These are automatically set when you add the Supabase integration:
- `SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_PUBLISHABLE_KEY`
- `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `SUPABASE_JWT_SECRET`
- `POSTGRES_URL`
- `POSTGRES_URL_NON_POOLING`
- `POSTGRES_PRISMA_URL`
- `POSTGRES_HOST`
- `POSTGRES_DATABASE`
- `POSTGRES_USER`
- `POSTGRES_PASSWORD`

### Optional
- `LETTERMAN_API_KEY` - Enables Article Board publishing to Letterman
- `POSTBRIDGE_API_KEY` - Enables Video Cue social media publishing

---

## 🎓 Database Schema

The 12 migration files create these tables and features:

### Migration 1: `clips` table
- Video clips from various sources
- Fields: id, title, url, thumbnail, source, created_at, updated_at

### Migration 2: Content tables
- `ideas` - Ideas tracker
- `bookmarks` - Resource library links
- `projects` - Project management
- `shopping_items` - Wish list items

### Migration 3: `settings` table
- User preferences and configuration

### Migration 4: Postbridge integration
- Adds post_id field for social publishing tracking

### Migration 5: User isolation
- Adds user_id to clips and vault for multi-user support

### Migration 6: Business tables
- `business_projects` - Business ventures
- `revenue_streams` - Income tracking
- Business metrics and KPIs

### Migration 7: Articles user support
- Multi-user article management

### Migration 8: Team board
- `team_members` - Team collaboration
- Role assignments

### Migration 9: Command center
- `sales_data` - Sales tracking
- `ad_data` - Advertising metrics
- `system_status` - System monitoring

### Migration 10: Team members
- Enhanced team management features

### Migration 11: Kanban tasks
- `kanban_tasks` - Project board task management
- Drag-and-drop support

### Migration 12: Commands user support
- Multi-user command reference

All tables include Row Level Security (RLS) policies for secure multi-user access.

---

## ✅ Deployment Checklist

Track your progress:

- [ ] **Step 1:** Forked the GitHub repository
- [ ] **Step 2:** Installed Supabase integration and created project
- [ ] **Step 3:** Copied .env.local snippet to Notepad
- [ ] **Step 4:** Connected Vercel to GitHub and imported repository
- [ ] **Step 5:** Pasted all Supabase variables to Vercel
- [ ] **Step 6:** Deployed to Vercel successfully
- [ ] **Step 7:** Ran all 12 database migrations
- [ ] **Step 8:** Created first user account
- [ ] **Step 9:** Tested login and all boards
- [ ] **Step 10:** Populated Command Center with OpenClaw commands (optional)

---

## 🆘 Need Help?

- **Vercel docs:** https://vercel.com/docs
- **Supabase docs:** https://supabase.com/docs
- **Next.js docs:** https://nextjs.org/docs
- **Source code:** https://github.com/pacinobot2026/control-board

---

**🎉 Congratulations on deploying your Control Board!**

You now have a complete operational dashboard with 10+ boards for managing your business, projects, content, and resources.
